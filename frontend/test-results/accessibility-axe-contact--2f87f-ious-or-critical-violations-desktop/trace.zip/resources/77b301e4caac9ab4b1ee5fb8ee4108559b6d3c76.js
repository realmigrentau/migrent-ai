__turbopack_load_page_chunks__("/for-owners", [
  "static/chunks/a2010eed650d961b.js",
  "static/chunks/c8e1d6cd92b7ffcc.js",
  "static/chunks/9e47a085ea836af0.js",
  "static/chunks/281eb2b73c7fe11d.js",
  "static/chunks/00acdcdc7f4d8f8e.js",
  "static/chunks/71c8b86893c65154.js",
  "static/chunks/f0bf03c4e7ee3177.js",
  "static/chunks/turbopack-aac380c8a12ab8e0.js"
])
