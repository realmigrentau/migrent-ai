__turbopack_load_page_chunks__("/faq", [
  "static/chunks/9cd5b5ec2fb9a6de.js",
  "static/chunks/a2010eed650d961b.js",
  "static/chunks/9e47a085ea836af0.js",
  "static/chunks/b5065bbf36b3cfcc.js",
  "static/chunks/281eb2b73c7fe11d.js",
  "static/chunks/c8e1d6cd92b7ffcc.js",
  "static/chunks/71c8b86893c65154.js",
  "static/chunks/00acdcdc7f4d8f8e.js",
  "static/chunks/turbopack-455bd268b6d4a219.js"
])
