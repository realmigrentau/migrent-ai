__turbopack_load_page_chunks__("/", [
  "static/chunks/92dd011550b4742b.js",
  "static/chunks/a2010eed650d961b.js",
  "static/chunks/35877f013eabaf1f.js",
  "static/chunks/6d157d94ba1040f8.js",
  "static/chunks/281eb2b73c7fe11d.js",
  "static/chunks/00acdcdc7f4d8f8e.js",
  "static/chunks/9e47a085ea836af0.js",
  "static/chunks/c8e1d6cd92b7ffcc.js",
  "static/chunks/71c8b86893c65154.js",
  "static/chunks/turbopack-65c55235287be30f.js"
])
