__turbopack_load_page_chunks__("/signup", [
  "static/chunks/fee68762721806c6.js",
  "static/chunks/9e47a085ea836af0.js",
  "static/chunks/b5065bbf36b3cfcc.js",
  "static/chunks/771ba8c220ea868b.js",
  "static/chunks/281eb2b73c7fe11d.js",
  "static/chunks/c8e1d6cd92b7ffcc.js",
  "static/chunks/00acdcdc7f4d8f8e.js",
  "static/chunks/f8cc25bfa4f6b2e9.js",
  "static/chunks/71c8b86893c65154.js",
  "static/chunks/turbopack-23f69dfa17ba9d70.js"
])
