__turbopack_load_page_chunks__("/privacy-policy", [
  "static/chunks/37946f6f1a6c3cb3.js",
  "static/chunks/c8e1d6cd92b7ffcc.js",
  "static/chunks/a2010eed650d961b.js",
  "static/chunks/00acdcdc7f4d8f8e.js",
  "static/chunks/281eb2b73c7fe11d.js",
  "static/chunks/71c8b86893c65154.js",
  "static/chunks/9e47a085ea836af0.js",
  "static/chunks/turbopack-0e1f7b9144d384b1.js"
])
