__turbopack_load_page_chunks__("/forgot-password", [
  "static/chunks/fee68762721806c6.js",
  "static/chunks/45c8cae33908ae86.js",
  "static/chunks/9e47a085ea836af0.js",
  "static/chunks/c8e1d6cd92b7ffcc.js",
  "static/chunks/00acdcdc7f4d8f8e.js",
  "static/chunks/281eb2b73c7fe11d.js",
  "static/chunks/71c8b86893c65154.js",
  "static/chunks/f8cc25bfa4f6b2e9.js",
  "static/chunks/turbopack-0e97819d8309aa47.js"
])
