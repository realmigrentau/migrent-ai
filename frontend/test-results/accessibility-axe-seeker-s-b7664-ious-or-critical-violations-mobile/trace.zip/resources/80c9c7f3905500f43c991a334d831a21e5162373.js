__turbopack_load_page_chunks__("/listing/[id]", [
  "static/chunks/a2010eed650d961b.js",
  "static/chunks/fee68762721806c6.js",
  "static/chunks/71c8b86893c65154.js",
  "static/chunks/9e47a085ea836af0.js",
  "static/chunks/030c7ed9e516ae9b.js",
  "static/chunks/f8cc25bfa4f6b2e9.js",
  "static/chunks/00acdcdc7f4d8f8e.js",
  "static/chunks/281eb2b73c7fe11d.js",
  "static/chunks/9f90c10c8ac0d5b9.js",
  "static/chunks/c8e1d6cd92b7ffcc.js",
  "static/chunks/25c826f0022faa09.js",
  "static/chunks/turbopack-48720ae641e890a8.js"
])
